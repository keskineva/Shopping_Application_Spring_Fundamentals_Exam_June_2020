package shopping.model.entity;

public enum CategoryName {
    FOOD, DRINK, HOUSEHOLD, OTHER;
}
